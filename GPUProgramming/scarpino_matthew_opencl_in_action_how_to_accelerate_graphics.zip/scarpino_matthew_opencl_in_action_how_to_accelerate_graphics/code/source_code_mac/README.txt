As of October 2011, Mac OS systems do not support OpenCl v1.1 or OpenGL v3.3. In addition, Mac OS does not support OpenCL images.

I have removed all example code that relies on unsupported capabilities. I have also added cl.hpp to Ch8 because the OpenCL framework on Mac OS systems doesn't include this important header.
